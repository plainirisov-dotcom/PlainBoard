package com.plainboard.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var page: LinearLayout
    private val prefs by lazy { getSharedPreferences("board", 0) }
    private val types = arrayOf("normal", "title", "upper", "lower", "alternate")
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); draw() }
    private fun field(hint: String, value: String = "") = EditText(this).apply { setSingleLine(true); this.hint = hint; setText(value) }
    private fun addButton(text: String, action: () -> Unit) { page.addView(Button(this).apply { this.text = text; setOnClickListener { action() } }) }
    private fun draw() {
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24) }
        val scroll = ScrollView(this).apply { addView(page) }; setContentView(scroll)
        page.addView(TextView(this).apply { text = "PlainBoard 👑 0.1"; textSize = 25f; setTextColor(Color.BLACK) })
        addButton("1. Включить клавиатуру в настройках Android") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        addButton("2. Выбрать PlainBoard") { (getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).showInputMethodPicker() }
        addButton("🖼 Выбрать изображение из галереи") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }, 77)
        }
        addButton("Убрать фон") { prefs.edit().remove("background").apply(); Toast.makeText(this, "Фон убран", Toast.LENGTH_SHORT).show() }
        addButton("🎨 Цвет клавиш") {
            val colors = intArrayOf(0xffeef0f5.toInt(), 0xff222222.toInt(), 0xffc5b4ff.toInt(), 0xffffc6e7.toInt(), 0xff8fe5d0.toInt())
            AlertDialog.Builder(this).setTitle("Выбери цвет").setItems(arrayOf("Светлый", "Тёмный", "Фиолетовый", "Розовый", "Мятный")) { _, which -> prefs.edit().putInt("keyColor", colors[which]).apply() }.show()
        }
        page.addView(TextView(this).apply { text = "Режимы текста (нажми для редактирования)"; textSize = 19f })
        StyleEngine.load(this).forEachIndexed { index, style -> addButton("✏ ${style.name}") { editStyle(index) } }
        addButton("＋ Создать свой режим") { editStyle(null) }
        addButton("Сбросить режимы") { StyleEngine.save(this, StyleEngine.defaults); draw() }
        page.addView(TextView(this).apply { text = "Изменения оформления появляются при следующем открытии клавиатуры. Режимы переключаются кнопкой с названием режима." })
    }
    private fun editStyle(index: Int?) {
        val all = StyleEngine.load(this); val old = index?.let { all[it] } ?: TextStyle("Новый режим", "normal")
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 8, 18, 8) }
        val name = field("Название режима", old.name); layout.addView(name)
        val spinner = Spinner(this).apply { adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, arrayOf("Обычный", "Каждое слово с заглавной", "ВСЕ БОЛЬШИЕ", "все маленькие", "ЧеРеДоВаНиЕ")); setSelection(types.indexOf(old.type).coerceAtLeast(0)) }; layout.addView(spinner)
        val prefix = field("Префикс слова (например ✦)", old.prefix); layout.addView(prefix)
        val suffix = field("Суффикс слова (например ✦)", old.suffix); layout.addView(suffix)
        val from = field("Заменять символы (например абв)", old.replaceFrom); layout.addView(from)
        val to = field("На символы (например 123)", old.replaceTo); layout.addView(to)
        val punctuation = CheckBox(this).apply { text = "Убирать знаки препинания"; isChecked = old.removePunctuation }; layout.addView(punctuation)
        val dialog = AlertDialog.Builder(this).setTitle("Редактор стиля").setView(ScrollView(this).apply { addView(layout) }).setPositiveButton("Сохранить") { _, _ ->
            if (from.text.length != to.text.length) { Toast.makeText(this, "Для замены длины строк должны совпадать", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            val style = TextStyle(name.text.toString().ifBlank { "Без названия" }, types[spinner.selectedItemPosition], prefix.text.toString(), suffix.text.toString(), from.text.toString(), to.text.toString(), punctuation.isChecked)
            if (index == null) all.add(style) else all[index] = style
            StyleEngine.save(this, all); draw()
        }.setNegativeButton("Отмена", null)
        if (index != null) dialog.setNeutralButton("Удалить") { _, _ -> if (all.size > 1) { all.removeAt(index); StyleEngine.save(this, all); draw() } }
        dialog.show()
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77 && resultCode == RESULT_OK && data?.data != null) {
            val uri = data.data!!
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.edit().putString("background", uri.toString()).apply()
            Toast.makeText(this, "Фон сохранён", Toast.LENGTH_SHORT).show()
        }
    }
}
