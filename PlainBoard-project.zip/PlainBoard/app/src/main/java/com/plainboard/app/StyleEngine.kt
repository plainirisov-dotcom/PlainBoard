package com.plainboard.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class TextStyle(val name: String, val type: String, val prefix: String = "", val suffix: String = "", val replaceFrom: String = "", val replaceTo: String = "", val removePunctuation: Boolean = false)

object StyleEngine {
    val defaults = listOf(TextStyle("Обычный", "normal"), TextStyle("👑 Королева", "title", removePunctuation = true), TextStyle("📢 КРИК", "upper"), TextStyle("🌀 Хаос", "alternate"), TextStyle("✨ Украшения", "normal", prefix = "✦", suffix = "✦"))
    fun load(ctx: Context): MutableList<TextStyle> { return try {
        val raw = ctx.getSharedPreferences("board", 0).getString("styles", null) ?: return defaults.toMutableList()
        val array = JSONArray(raw)
        MutableList(array.length()) { i -> val j = array.getJSONObject(i); TextStyle(j.optString("name"), j.optString("type", "normal"), j.optString("prefix"), j.optString("suffix"), j.optString("from"), j.optString("to"), j.optBoolean("punctuation")) }.also { if (it.isEmpty()) return defaults.toMutableList() }
    } catch (_: Exception) { defaults.toMutableList() }
    }
    fun save(ctx: Context, styles: List<TextStyle>) {
        val arr = JSONArray()
        styles.forEach { s -> arr.put(JSONObject().put("name", s.name).put("type", s.type).put("prefix", s.prefix).put("suffix", s.suffix).put("from", s.replaceFrom).put("to", s.replaceTo).put("punctuation", s.removePunctuation)) }
        ctx.getSharedPreferences("board", 0).edit().putString("styles", arr.toString()).apply()
    }
    fun convertChar(s: TextStyle, char: String, startOfWord: Boolean, charIndex: Int): String {
        if (s.removePunctuation && char.firstOrNull()?.let { !it.isLetterOrDigit() && !it.isWhitespace() } == true) return ""
        val mapped = if (s.replaceFrom.isNotEmpty() && s.replaceFrom.length == s.replaceTo.length) {
            val pos = s.replaceFrom.indexOf(char); if (pos >= 0) s.replaceTo[pos].toString() else char
        } else char
        return when (s.type) {
            "title" -> if (startOfWord) mapped.uppercase(Locale.getDefault()) else mapped.lowercase(Locale.getDefault())
            "upper" -> mapped.uppercase(Locale.getDefault())
            "lower" -> mapped.lowercase(Locale.getDefault())
            "alternate" -> if (charIndex % 2 == 0) mapped.lowercase(Locale.getDefault()) else mapped.uppercase(Locale.getDefault())
            else -> mapped
        }
    }
}
