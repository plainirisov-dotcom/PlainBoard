package com.plainboard.app

import android.inputmethodservice.InputMethodService
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class PlainKeyboard : InputMethodService() {
    private lateinit var root: LinearLayout
    private var russian = true
    private var shifted = false
    private var mode = 0
    private var wordStart = true
    private var typedCount = 0
    private var styles = StyleEngine.defaults.toMutableList()
    private val ru = listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
    private val en = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    override fun onCreateInputView(): View { root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 8, 4, 8) }; refresh(); return root }
    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) { super.onStartInput(attribute, restarting); wordStart = true; typedCount = 0; if (::root.isInitialized) refresh() }
    private fun prefs() = getSharedPreferences("board", 0)
    private fun refresh() {
        styles = StyleEngine.load(this); mode = mode.coerceIn(0, styles.lastIndex)
        root.removeAllViews()
        root.setBackgroundColor(Color.rgb(34, 37, 46))
        val uri = prefs().getString("background", null)
        if (uri != null) try { contentResolver.openInputStream(Uri.parse(uri))?.use { stream ->
            val bitmap = BitmapFactory.decodeStream(stream)
            if (bitmap != null) root.background = BitmapDrawable(resources, bitmap).apply { alpha = 150 }
        } } catch (_: Exception) { }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(button(styles[mode].name, 2f) { mode = (mode + 1) % styles.size; refresh() })
        tools.addView(button(if (russian) "RU" else "EN", 1f) { russian = !russian; refresh() })
        tools.addView(button("⚙", 1f) { startActivity(Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        root.addView(tools)
        (if (russian) ru else en).forEach { letters ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            letters.forEach { c -> row.addView(button(if (shifted) c.uppercase() else c.toString(), 1f) { insert(if (shifted) c.uppercase() else c.toString()) }) }
            root.addView(row)
        }
        val extra = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        extra.addView(button("⇧", 1f) { shifted = !shifted; refresh() })
        extra.addView(button(",", 1f) { insert(",") })
        extra.addView(button("Пробел", 4f) { insert(" ") })
        extra.addView(button(".", 1f) { insert(".") })
        extra.addView(button("⌫", 1f) { currentInputConnection?.deleteSurroundingText(1, 0); updateWordState() })
        root.addView(extra)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(button("?123", 1f) { insert("1") }) // placeholder: numeric layout is planned
        bottom.addView(button("↵", 2f) { currentInputConnection?.performEditorAction(EditorInfo.IME_ACTION_DONE) ?: currentInputConnection?.commitText("\n", 1) })
        bottom.addView(button("🌐", 1f) { switchToNextInputMethod(false) })
        root.addView(bottom)
    }
    private fun button(text: String, weight: Float, action: () -> Unit): Button {
        val color = prefs().getInt("keyColor", Color.rgb(238, 240, 245))
        return Button(this).apply {
            this.text = text; textSize = 15f; isAllCaps = false; setTextColor(if (Color.luminance(color) > .5) Color.BLACK else Color.WHITE)
            background = GradientDrawable().apply { setColor(color); cornerRadius = 12f }
            val p = LinearLayout.LayoutParams(0, (48 * resources.displayMetrics.density).toInt(), weight).apply { setMargins(2, 3, 2, 3) }
            layoutParams = p; setOnClickListener { action() }
        }
    }
    private fun updateWordState() {
        val before = currentInputConnection?.getTextBeforeCursor(1, 0)?.toString().orEmpty()
        wordStart = before.isEmpty() || before.last().isWhitespace()
    }
    private fun insert(raw: String) {
        val style = styles[mode]
        val converted = StyleEngine.convertChar(style, raw, wordStart, typedCount)
        if (converted.isEmpty()) return
        val result = (if (wordStart && !raw.first().isWhitespace()) style.prefix else "") + converted + (if (raw.first().isWhitespace() && !wordStart) style.suffix else "")
        currentInputConnection?.commitText(result, 1)
        wordStart = raw.last().isWhitespace(); if (!wordStart) typedCount++
    }
}
