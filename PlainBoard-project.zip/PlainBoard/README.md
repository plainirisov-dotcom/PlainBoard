# PlainBoard 0.1

Native Android IME (InputMethodService), written in Kotlin. No internet permission, no analytics, no network calls.

## Build
1. Install Android Studio (Ladybug or newer) with Android SDK 35.
2. Open this folder as a project and wait for Gradle sync.
3. Build > Build APK(s). Find APK at `app/build/outputs/apk/debug/app-debug.apk`.
4. Install APK, open PlainBoard, enable it in Android keyboard settings and select it as the active input method.

## Features
- Russian and English letter layouts, Shift, backspace, space, mode switching, next keyboard, settings.
- Live per-character style transformations: normal, title case, uppercase, lowercase, alternating case, punctuation filtering.
- Create, edit, delete style presets, prefix/suffix, one-to-one character substitution.
- Background image from Android document picker and selectable key colors.
- Settings are local only; images are opened with Android's persisted read permission.

## Known limitations (prototype)
- `?123` is a placeholder that currently inserts `1`, not a complete numeric keyboard.
- No suggestions, swipe typing, emoji picker, sound effects, or layout sizing editor yet.
- The prefix/suffix behavior is experimental and suffix is inserted when space is typed.
- Switching mode does not retroactively change previously typed text.
- Backspace and word detection are basic, and password fields have not been specially handled.
- Background image decoding is not optimized for very large photos.
- Needs Android SDK/Gradle to produce APK; no APK is included in this archive.
